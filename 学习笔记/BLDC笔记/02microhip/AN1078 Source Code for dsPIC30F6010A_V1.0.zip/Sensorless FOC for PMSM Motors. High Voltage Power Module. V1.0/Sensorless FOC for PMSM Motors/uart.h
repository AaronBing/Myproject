void DumpBuffer(WORD iNum, short *pBuf, short iNumCol);

void ResetUART(void);
void SetupUART(void);
void SetupUARTFast(void);
void SendUARTShort( short s );
void SendUARTByte( BYTE b );

