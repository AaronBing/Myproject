short Q15Multiply(short q1, short q2);

