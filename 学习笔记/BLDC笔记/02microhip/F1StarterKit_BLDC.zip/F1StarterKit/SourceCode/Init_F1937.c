/************************************************************************
*                                                                       *
*     Project              : 3-Phase Brushless Motor Control            *
*                                                                       *
*     Author               : W.R.Brown                                  *
*     Company              : Microchip Technology Incorporated          *
*     Filename             : Init_F1937.c                               *
*     Date                 : 2009/08/24                                 *
*     Version              : 1.0                                        *
*                                                                       *
*     Other Files Required : BLDC.h                                     *
*     Tools Used: MPLAB GL : 8.14                                       *
*                 Compiler : Hi-Tech                                    *
*                 Assembler:                                            *
*                 Linker   :                                            *
*                                                                       *
*************************************************************************

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
//  System initialization for PIC16F1937 BLDC systems.                                                //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
*                
*
*********************************************************************
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
*
* Change History:
* Author               Date        Comment

* w.r.brown            2009.08.24  V 1.0  - System initialization only
*******************************************************************************************************/
#include <htc.h>
#include "BLDC.h"
#ifdef PC_CONTROL
#include "Monitor.h"
#endif

/************************************************************************
* variable definitions                                                  *
*************************************************************************/

extern unsigned char comm_state;

extern doublebyte zc;
extern doublebyte TMR1_comm_time;

extern char slow_start_events;
extern unsigned char TMR0_slow_start_timer;
extern unsigned char TMR0_stall_timer;
extern unsigned char TMR0_warmup_timer;
extern unsigned char TMR0_duty_timer;
extern unsigned char TMR0_stallcheck_timer;
extern unsigned char timebase_10ms;

extern bit TMR0_startup_flag;
extern bit TMR0_warmup_flag;
extern bit TMR0_slow_start_flag;
extern bit TMR0_stall_flag;
extern bit TMR0_duty_flag;
extern bit warmup_complete_flag;
extern bit startup_complete_flag;
extern bit slow_start_complete_flag;
extern bit stall_flag;
extern bit stall_recovery_flag;
extern bit stop_flag;
extern bit run_flag;
extern bit init_complete_flag;
extern bit rising_bemf_flag;
extern bit measure_bemf_flag;
extern bit startup_in_progress;

extern int zc_error;
extern int temp;
extern char ctemp;
extern doublebyte expected_zc;
extern doublebyte comm_after_zc;
extern unsigned char ramped_speed;

extern unsigned char startup_dutycycle;
extern unsigned int startup_rpm;

extern enum {zero_detect,commutate}isr_state;;
extern const int CCP_Values[256];

/************************************************************************
*                                                                       *
*      Function:       InitSystem                                       *
*                                                                       *
*      Description:    initialize system registers and variables        *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*************************************************************************/

void InitSystem(void) {

   // disable interrupts
   PEIE=0;   
   GIE=0;

   // Setup internal oscillator frequency
   OSCCON = OSCCON_INIT;
   
   //OPTION=OPTION_INIT;   

   // set all ports tristate
   
   TRISA = 0xFF;
   TRISB = 0xFF;
   TRISC = 0xFF;
   
   // initialize ports
   
   PORTA=PORTA_INIT;
   TRISA=TRISA_INIT;

   PORTB=PORTB_INIT;
   TRISB=TRISB_INIT;

   PORTC=PORTC_INIT;
   TRISC=TRISC_INIT;

#ifdef PORTD_INIT
   PORTD=PORTD_INIT;
   TRISD=TRISD_INIT;
#endif
   
#ifdef PORTE_INIT
   PORTE=PORTE_INIT;
   TRISE=TRISE_INIT;
#endif
   
   // initialize ADC
   
   ANSELA=ANSELA_INIT;
   ANSELB=ANSELB_INIT;
   ANSELD=ANSELD_INIT;
   ANSELE=ANSELE_INIT;

   ADCON0 = ADCON0_INIT;
   ADCON1 = ADCON1_INIT;
   
   CCP1CON = 0;            //disable PWM

   // TIMER0 and related startup variables
   TMR0 = 0;
   T0IF = 0;
   OPTION_REG = OPTION_REG_INIT;
   TMR0_warmup_timer = TIMEBASE_WARMUP_COUNT;
   TMR0_slow_start_timer = TIMEBASE_SLOW_STEP;
   TMR0_duty_timer = TIMEBASE_DUTY_RAMP;
   TMR0_stallcheck_timer = TIMEBASE_STALLCHECK_COUNT;
   TMR0_stall_timer = TIMEBASE_STALL_COUNT;
   timebase_10ms = TIMEBASE_LOAD_10ms;
   
   // Timebase manager flags
   TMR0_startup_flag = 0;
   TMR0_warmup_flag = 0;
   TMR0_stall_flag = 0;
   TMR0_slow_start_flag = 0;
   TMR0_duty_flag = 0;
   TMR0_duty_flag = 0;
   slow_start_events = SLOW_STEPS;
   warmup_complete_flag = 0;
   startup_complete_flag = 0;
   slow_start_complete_flag = 0;
   stall_flag = 0;
   startup_in_progress = 0;
   stop_flag = 0;
   run_flag = 0;

   // TIMER1 
   T1CON = T1CON_INIT;

   // COMPARATORS
   CMxCON0 = CMxCON0_INIT;
   //CMyCON0 = CMyCON0_INIT;

   // DRIVER init
   PR2 = PWM_PERIOD;
   T2CON = T2CON_INIT;
   
   measure_bemf_flag = 0;
   zc_error = 0;
   temp = 0;
   ctemp = 0;
   expected_zc.word = 0;
   zc.word = 0;
   comm_after_zc.word = 0;
   ramped_speed = 0;
   //startup_dutycycle = MED_STARTUP_DUTYCYCLE;
      
   init_complete_flag = 0;   
}

/************************************************************************
*                                                                       *
*      Function:       InitDriver                                       *
*                                                                       *
*      Description:     initialize PWM and driver registers & variables *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*  Drivers are initialized after the warmup period and when restarting  *
*  after a stop or stall event.                                         *
*                                                                       *
*************************************************************************/

void InitDriver(void) 
{
   // startup duty cycle is set by SupplyManager()
   ramped_speed = FindTableIndex(startup_dutycycle);
   GetCCPVal(ramped_speed);
   CCP1CON = CCP1CON_INIT;        //    PWM on
#ifdef ECCPAS_INIT
   ECCPAS = ECCPAS_INIT;        // autoshutdown mode
   PWM1CON = PWM1CON_INIT;        // restart mode
#endif

   TMR1_comm_time.word = startup_rpm; //0xFFFF - COMM_TIME_INIT + 1;
   
   // expected_zc is negative expected time remaining at zero cross event
   expected_zc.word = (TMR1_comm_time.word>>1) | 0x8000;
           
   comm_state=1;
   Commutate();

   startup_in_progress = 1;
   init_complete_flag = 1;   
}
