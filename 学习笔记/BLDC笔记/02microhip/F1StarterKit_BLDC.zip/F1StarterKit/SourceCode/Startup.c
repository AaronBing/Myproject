/************************************************************************
*                                                                       *
*     Project              : 3-Phase Brushless Motor Control            *
*                                                                       *
*     Author               : W.R.Brown                                  *
*     Company              : Microchip Technology Incorporated          *
*     Filename             : Startup.c                                  *
*     Date                 : 2009/08/24                                 *
*     Version              : 1.0                                        *
*                                                                       *
*     Other Files Required : BLDC.h                                     *
*     Tools Used: MPLAB GL : 8.14                                       *
*                 Compiler : Hi-Tech                                    *
*                 Assembler:                                            *
*                 Linker   :                                            *
*                                                                       *
*************************************************************************

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
//  BLDC Startup. This version immediatly releases to run mode after prealigning the motor for        //
//  a fixed duration.                                                                                 //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
*                
*
*********************************************************************
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
*
* Change History:
* Author               Date        Comment

* w.r.brown            2009.08.24  V 1.0  - Startup routines only
*******************************************************************************************************/
#include <htc.h>
#include "BLDC.h"
#ifdef PC_CONTROL
#include "Monitor.h"
#endif

/************************************************************************
* variable definitions                                                  *
*************************************************************************/

extern doublebyte TMR1_comm_time;

extern char slow_start_events;
extern unsigned char TMR0_slow_start_timer;
extern unsigned char TMR0_startup_timer;

extern bit TMR0_startup_flag;
extern bit TMR0_slow_start_flag;
extern bit startup_complete_flag;
extern bit slow_start_complete_flag;
extern bit stop_flag;
extern bit init_complete_flag;
extern bit startup_in_progress;
extern enum {zero_detect,commutate}isr_state;

/************************************************************************
*                                                                       *
*      Function:       ControlSlowStart                                 *
*                                                                       *
*      Description:  Dwell at two successive commutations before        *
*                   starting the spin up                                *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*  This is called every main loop cycle but the TMR0_slow_start_flag    *
*  limits execution to every 10 ms as defined by the TimeBaseManager()  *
*  routine.                                                             *
*                                                                       *
*************************************************************************/

void ControlSlowStart(void)
{
   if(!init_complete_flag) return;           // exit if not initialized
   if(slow_start_complete_flag) return;      // exit if slow start ended
   if(!(TMR0_slow_start_flag)) return;       // hold off for 10 ms
   
   TMR0_slow_start_flag = 0;
   // The slow start timer determines how long to dwell at each slow
   // start commutation point.
   if(--TMR0_slow_start_timer == 0)
   {  // when slow start is complete change to the startup timer
      // which determines how long to ramp-up at fixed commutations
      // the ramp-up is terminated early when the first zero cross
      // is detected.
      if(--slow_start_events == 0)
      {
         //TP0 = 1;  // Diagnostic
         slow_start_complete_flag = 1;
         TMR0_startup_timer = TIMEBASE_STARTUP_COUNT;
         TMR1H = TMR1_comm_time.bytes.high;
         TMR1L = TMR1_comm_time.bytes.low;
         isr_state = commutate;
         TMR1ON = 1;
         TMR1IE = 1;
         PEIE=1;   
         GIE=1;
      }
      else
      {  // reset the dwell timer for the next step
         TMR0_slow_start_timer = TIMEBASE_SLOW_STEP;
         Commutate();
      }
   }
}   

/************************************************************************
*                                                                       *
*      Function:       ControlStartup                                   *
*                                                                       *
*      Description:     check startup flags and timing                  *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*  Zero cross must be detected within the middle 25% of the             *
*  commutation period before the startup timer expires otherwise        *
*  the motor will be shut down.                                         *
*                                                                       *
*  Startup time is determined by the constant TIMEBASE_STARTUP_COUNT    *
*  which is defined in BLDC.h. Maximum startup time is 2.55 seconds.    *
*  This is called every main loop cycle but the TMR0_startup_flag limits*  
*  execution to every 10 ms as defined by the TimeBaseManager() routine.*
*                                                                       *
*************************************************************************/

void ControlStartUp(void) 
{
   if(!slow_start_complete_flag) return;     // exit if slow start not ended
   if(!startup_in_progress) return;          // exit if startup ended
   if(!(TMR0_startup_flag)) return;          // hold off for 10 ms
   
   // This flag is set every 10 ms by the TimeBaseManager()
   TMR0_startup_flag = 0;   

   if(--TMR0_startup_timer == 0) 
   {
      // stable rotation will clear the startup_complete_flag.
      // if rotation is not stable by the time the startup is complete
      // then force a full reinitialization by setting the stop_flag..
      startup_in_progress = 0;
      if(!startup_complete_flag)
      {
         stop_flag=1;
      }   
   }
}
