/************************************************************************
*                                                                       *
*     Project              : 3-Phase Brushless Motor Control            *
*                                                                       *
*     Author               : W.R.Brown                                  *
*     Company              : Microchip Technology Incorporated          *
*     Filename             : StallControl.c                             *
*     Date                 : 2009/08/24                                 *
*     Version              : 1.0                                        *
*                                                                       *
*     Other Files Required : BLDC.h                                     *
*     Tools Used: MPLAB GL : 8.14                                       *
*                 Compiler : Hi-Tech                                    *
*                 Assembler:                                            *
*                 Linker   :                                            *
*                                                                       *
*************************************************************************

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
//   BLDC Stall detection                                                                             //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
*                
*
*********************************************************************
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
*
* Change History:
* Author               Date        Comment

* w.r.brown            2009.08.24  V 1.0  - Timebase manager invoked stall detection only
*******************************************************************************************************/
#include <htc.h>
#include "BLDC.h"
#ifdef PC_CONTROL
#include "Monitor.h"
#endif


/************************************************************************
* variable definitions                                                  *
*************************************************************************/

extern doublebyte TMR1_comm_time;

extern unsigned char TMR0_stall_timer;
extern unsigned char TMR0_stallcheck_timer;
extern unsigned char timebase_10ms;

extern bit TMR0_stall_flag;
extern bit startup_complete_flag;
extern bit stop_flag;
extern bit init_complete_flag;

/************************************************************************
*                                                                       *
*      Function:       StallControl                                     *
*                                                                       *
*      Description:     check motor stall and re-start                  *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*************************************************************************/

void StallControl(void) 
{   
   
   if(!init_complete_flag) return;      // exit if warmup
   if(!startup_complete_flag) return;
   if(!(TMR0_stall_flag)) return;       // wait TMR0 flag

   TMR0_stall_flag = 0;   

   // TMR0_stall_timer is reset every stable detect event
   // if no stable events are detected then the timer will 
   // time-out forcing the control into a stop condition.
   if(--TMR0_stall_timer == 0)
   {
      stop_flag=1;
   }   

   // The control algorithm and zero-cross detection will increase the commutation rate
   // in search of commutation period resulting in zero-cross detetion in the middle of the period.
   // The intrinsic reactance of the motor stator and rotor will produce a false zero-crossing
   // event of a stalled motor at a predictable commutation rate, depending on the motor and rotor 
   // position to the stator. This is usually a rate faster than the motor can actually spin.
   // When a commutation period as short as or shorter than the rate where false zero-crossing
   // events occur then a stall condition is detected and the motor is stopped.
   if(--TMR0_stallcheck_timer==0)
   {
      TMR0_stallcheck_timer = TIMEBASE_STALLCHECK_COUNT;
      
      // TMR1_comm_time is the preset value for the commutation period.
      // Commutation time is the time from preset value to overflow.
      // Larger numbers represent shorter periods.
      // If the algorithm sets TMR1_comm_time to a period shorter than
      // the stall trigger point then stop the motor.
      if((unsigned int)TMR1_comm_time.word > MAX_TMR1_PRESET)
      {
         stop_flag = 1;
      }   
   }
}
