/************************************************************************
*                                                                       *
*     Project              : 3-Phase Brushless Motor Control            *
*                                                                       *
*     Author               : W.R.Brown                                  *
*                                                                       *
*     Company              : Microchip Technology Incorporated          *
*     Filename             : DirectDrivers.c                            *
*     Date                 : 2008/03/21                                 *
*     SharePoint Version   : 1.0                                        *
*                                                                       *
*     Tools Used: MPLAB GL : 8.01                                       *
*                 Compiler : Hi-Tech                                    *
*                 Assembler:                                            *
*                 Linker   :                                            *
*                                                                       *
************************************************************************/

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// Discrete FET driver commutation states.                                                            //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////


/*******************************************************************************************************
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*******************************************************************************************************
*
*
*******************************************************************************************************
*
* Change History:
* Author               Date        Comment
* w.r.brown            2009.03.12  V 1.0  - Added header information
*******************************************************************************************************/

#include <htc.h>
#include "BLDC.h"

extern unsigned char comm_state; 
extern bit rising_bemf_flag;
bit ReverseDirection;

/************************************************************************
*                                                                       *
*      Function:       Commutate                                        *
*                                                                       *
*      Description:    driver commutation                               *
*                                                                       *
*      PSTRCON is used to steer PWM to one side of bridge and           *
*      DRIVE_PORT is used to drive other side. Comparator input         *
*      is steered to undriven phase of motor.                           *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*************************************************************************/

//
//    4|5|6|1|2|3|4|5|6|1|2|3|
//     | | |_|_| | | | |_|_| |
//  U _|_|/| | |\|_|_|/| | |\|
//    _| | | | |_|_| | | | |_|
//  V  |\|_|_|/| | |\|_|_|/| |
//     |_|_| | | | |_|_| | | |
//  W /| | |\|_|_|/| | |\|_|_|
//
// State  Low   High  Comparator
//   1     V     U       -W
//   2     W     U        V
//   3     W     V       -U
//   4     U     V        W
//   5     U     W       -V
//   6     V     W        U
//
void Commutate(void)
{
#ifdef HIGH_SIDE_MODULATION
   // High side modulation
   // BEMF is sensed when rising
   switch(comm_state) {
      case 1:
         PSTRCON    = MODULATE_U;
         DRIVE_PORT = DRIVE_V;
         COMPARATOR = SENSE_W_FALLING;
         rising_bemf_flag = 0;
         //comm_state = 7;         // comm_state decrement will reset this to 6
      break;
      case 2:
         TP1=1;                    // Diagnostic
       //PSTRCON    = MODULATE_U;
         DRIVE_PORT = DRIVE_W;
         COMPARATOR = SENSE_V_RISING;
         rising_bemf_flag = 1;
       //TP1=0;                  // Diagnostic
      break;
      case 3:
         PSTRCON    = MODULATE_V;
       //DRIVE_PORT = DRIVE_W;
         COMPARATOR = SENSE_U_FALLING;
         rising_bemf_flag = 0;
      break;
      case 4:
       //PSTRCON    = MODULATE_V;
         DRIVE_PORT = DRIVE_U;
         COMPARATOR = SENSE_W_RISING;
         rising_bemf_flag = 1;
      break;
      case 5:
         PSTRCON    = MODULATE_W;
       //DRIVE_PORT = DRIVE_U;
         COMPARATOR = SENSE_V_FALLING;
         rising_bemf_flag = 0;
      break;
      case 6:
         //PSTRCON  = MODULATE_W;
         DRIVE_PORT = DRIVE_V;
         COMPARATOR = SENSE_U_RISING;
         rising_bemf_flag = 1;
         comm_state=0;                  // comm_state increment will reset this to 1
      break;
      default:
         PSTRCON     = 0x00;            // Modulate off
         DRIVE_PORT = DRIVE_INIT;       // Drive off
         COMPARATOR = 0x00;
         rising_bemf_flag = 0;
         comm_state=1;
      break;
   };
#else
   // Low side modulation
   // BEMF is sensed when falling
   switch(comm_state) {
      case 1:
         PSTRCON    = MODULATE_V;
         DRIVE_PORT = DRIVE_U;
         COMPARATOR = SENSE_W_FALLING;
         rising_bemf_flag = 0;
       //comm_state = 7;              // comm_state decrement will reset this to 6
      break;
      case 2:
         PSTRCON    = MODULATE_W;
       //DRIVE_PORT = DRIVE_U;
         COMPARATOR = SENSE_V_RISING;
         rising_bemf_flag = 1;
      break;
      case 3:
       //PSTRCON    = MODULATE_W;
         DRIVE_PORT = DRIVE_V;
         COMPARATOR = SENSE_U_FALLING;
         rising_bemf_flag = 0;
      break;
      case 4:
         PSTRCON    = MODULATE_U;
       //DRIVE_PORT = DRIVE_V;
         COMPARATOR = SENSE_W_RISING;
         rising_bemf_flag = 1;
      break;
      case 5:
         TP1=1;                         // Diagnostic
       //PSTRCON    = MODULATE_U;
         DRIVE_PORT = DRIVE_W;
         COMPARATOR = SENSE_V_FALLING;
         rising_bemf_flag = 0;
       //TP1=0;                       // Diagnostic
      break;
      case 6:
         PSTRCON    = MODULATE_V;
       //DRIVE_PORT = DRIVE_W;
         COMPARATOR = SENSE_U_RISING;
         rising_bemf_flag = 1;
         comm_state=0;                  // comm_state increment will reset this to 1
      break;
      default:
         PSTRCON    = 0x00;             // Modulate off
         DRIVE_PORT = DRIVE_INIT;       // Fixed drive off
         COMPARATOR = 0x00;
         rising_bemf_flag = 0;
         comm_state=0;
      break;
   };
#endif   
   // setup for next commutation event
   comm_state++;
   
} // end Commutate
   