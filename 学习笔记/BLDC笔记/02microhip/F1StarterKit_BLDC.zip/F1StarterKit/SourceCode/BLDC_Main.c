/************************************************************************
*                                                                       *
*     Project              : 3-Phase Brushless Motor Control            *
*                                                                       *
*     Author               : W.R.Brown                                  *
*                        (original program structure: Loris Bianchin)   *
*     Company              : Microchip Technology Incorporated          *
*     Filename             : BLDC_Main.c                                *
*     Date                 : 2009/08/24                                 *
*     Version              : 1.0                                        *
*                                                                       *
*     Other Files Required : BLDC.h                                     *
*     Tools Used: MPLAB GL : 8.14                                       *
*                 Compiler : Hi-Tech                                    *
*                 Assembler:                                            *
*                 Linker   :                                            *
*                                                                       *
*************************************************************************

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
//                           Sensorless 3-phase brushless motor control                               //
//                                                                                                    //
// Hardware -                                                                                         //
// This program uses the steerable ECCP PWM to modulate the high or low sides                         //
// of a 3-phase motor drive bridge. Resistor dividers on the motor phases                             //
// are used to scale the back EMF (BEMF) and drive voltages to levels within range                    //
// of the device comparator. The positive comparator input monitors the motor supply                  //
// voltage, and the negative comparator input monitors the BEMF. The comparator                       //
// input mux is used to steer the undriven motor phase to the negative comparator                     //
// input. Zero cross is detected when the comparator negative input crosses half the                  //
// motor supply voltage. Zero cross is detected during either falling or rising BEMF only.            //
// Rising BEMF is sensed in systems with high-side modulation. Falling BEMF is sensed in              //
// systems with low-side modulation.                                                                  //
// Three timers are used. Timer0 controls the warmup time, startup time, and times between            //
// maintenance events such as reading the ADC for speed control. Timer2 sets the PWM period.          //
// Timer1 controls the commutation period.                                                            //
//                                                                                                    //
// Software -                                                                                         //
// There are 3 stages of operation which are controlled by the TimeBaseManager():                     //
// Warmup - Commences immediately after reset. Lasts for 400 mS. Device peripherals                   //
//    are initialized.                                                                                //
// Startup - Commences immediately after warmup. Lasts for 300 mS. I/O drivers                        //
//    are initialized, interrupts are enabled, and forced commutation begins.                         //
//    The motor drive PWM is fixed at the lowest duty cycle. The commutation rate                     //
//    starts slowly and ramps up based on the zero cross detection.                                   //
// Run - Commences immediately after startup. Commutation period is measured by reading               //
//    the Timer1 count at the zero cross event. All motor operation is interrupt driven.              //
//    There are two types of vectored interrupts:                                                     //
//    1. Timer1 commutation interrupt - Motor drive is changed to the next commutation phase.         //
//       If the new commutation period is a BEMF sense period then blanking is performed and          //
//       the comparators are setup for zero-crossing detection.                                       //
                                                                                                      //
//    2. Comparator Zero Cross interrupt - This signals when the BEMF voltage has crossed             //
//       half the motor supply voltage. Timer1 is read and the measured time is saved to be           //
//       used in computing the adjusted commutation period.                                           //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
*                
*
*********************************************************************
* Software License Agreement:
*
* The software supplied herewith by Microchip Technology Incorporated
* (the "Company") for its PICmicro� Microcontroller is intended and
* supplied to you, the Company's customer, for use solely and
* exclusively on Microchip PICmicro Microcontroller products. The
* software is owned by the Company and/or its supplier, and is
* protected under applicable copyright laws. All rights are reserved.
* Any use in violation of the foregoing restrictions may subject the
* user to criminal sanctions under applicable laws, as well as to
* civil liability for the breach of the terms and conditions of this
* license.
*
* THIS SOFTWARE IS PROVIDED IN AN "AS IS" CONDITION. NO WARRANTIES,
* WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
* TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
* IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
* CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
*********************************************************************
*
* Change History:
* Author               Date        Comment

* w.r.brown            2009.08.24  V 1.0  - Main timebase manager calls only
*******************************************************************************************************/
#include <htc.h>
#include "BLDC.h"
#ifdef PC_CONTROL
#include "Monitor.h"
#endif

#include "Config.inc"

/************************************************************************
* variable definitions                                                  *
*************************************************************************/

unsigned char comm_state;

doublebyte TMR1_comm_time;
doublebyte zc;
doublebyte expected_zc;
doublebyte comm_after_zc;

char slow_start_events;
unsigned char TMR0_slow_start_timer;
unsigned char TMR0_startup_timer;
unsigned char TMR0_stall_timer;
unsigned char TMR0_warmup_timer;
unsigned char TMR0_duty_timer;
unsigned char TMR0_stallcheck_timer;
unsigned char timebase_10ms;

bit TMR0_startup_flag;
bit TMR0_warmup_flag;
bit TMR0_slow_start_flag;
bit TMR0_stall_flag;
bit TMR0_duty_flag;
bit warmup_complete_flag;
bit startup_complete_flag;
bit slow_start_complete_flag;
bit stall_flag;
bit stall_recovery_flag;
bit stop_flag;
bit run_flag;
bit init_complete_flag;
bit rising_bemf_flag;
bit measure_bemf_flag;
bit startup_in_progress;

int zc_error;
int temp;
char ctemp;
unsigned char ramped_speed;

unsigned char startup_dutycycle = MED_STARTUP_DUTYCYCLE;
unsigned int startup_rpm = (0xFFFF - COMM_TIME_INIT + 1);

extern const int CCP_Values[256];

/************************************************************************
*                                                                       *
*                              M A I N                                  *
*                                                                       *
*************************************************************************/
void main(void)
{
   stop_flag = 1;
#ifdef PC_CONTROL
   MonitorInit();
#endif   
    
   while(1) {
      CLRWDT();
      if(stop_flag) InitSystem();
      TimeBaseManager();
      WarmUpControl();
      ControlSlowStart();
      ControlStartUp();
      StallControl();
      SpeedManager();

   }   

} // end main

/************************************************************************
*                         E N D   M A I N                               *
*************************************************************************/


/************************************************************************
*                                                                       *
*      Function:       TimeBaseManager                                  *
*                                                                       *
*      Description:     manage time base timer TIMER0 @ 16.3ms          *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*  The TimeBaseManager() is called in the main loop. There are several  *
*  timers in the system which are all controlled by the TimeBaseManager.*
*  The TimeBaseManager() base time resolution is 10mS set by the        * 
*  constant TIMEBASE_LOAD_10ms. All other timers inherit this           *
*  resolution.                                                          *
*  The TimeBaseManager() sets all subroutine timer flags which each     *
*  subroutine then receives as a signal to update their respective      *
*  timers.                                                              *
*                                                                       *
*************************************************************************/
void TimeBaseManager(void) 
{
   doublebyte tmr0_temp;
   
	if(T0IF) {
		T0IF = 0;
		TMR0 += TIMEBASE_MANAGER_RELOAD_COUNT;
 
		if(timebase_10ms) {
			timebase_10ms--;
			return;								// wait 10ms
		}

		// 10ms TIMEBASE timer
		//--------------------------------------------------------------------------
		timebase_10ms = TIMEBASE_LOAD_10ms;

      // TMR0 warmup timer update
      TMR0_warmup_flag = 1;
      //if(TMR0_warmup_timer) TMR0_warmup_timer--;

      // TMR0 slow start timer update
      TMR0_slow_start_flag = 1;

      // TMR0 startup timer update
      TMR0_startup_flag = 1;
   
      // TMR0 stall timer update
      TMR0_stall_flag = 1;

      // TMR0 duty ramp timer update
      //    "duty" refers to the PWM duty cycle. The PWM duty cycle
      //    is determined by getting a value from the SpeedManager()
      //    The duty cycle change rate is limited by this
      //    timer which permits one increment/decrement of the duty cycle
      //    register every N mS (set by the TIMEBASE_DUTY_RAMP constant).
      TMR0_duty_flag = 1;
      
   }
}

/************************************************************************
*                                                                       *
*      Function:       WarmUpControl                                    *
*                                                                       *
*      Description:     initialize system after warm up                 *
*                                                                       *
*      Parameters:                                                      *
*      Return value:                                                    *
*                                                                       *
*      Note:                                                            *
*                                                                       *
*  Warmup period is controlled by the TimeBaseManager(). Nothing in the *
*  system starts until the warmup period of TIMEBASE_WARMUP_ms has      *
*  elapsed.                                                             *
*                                                                       *
*************************************************************************/

void WarmUpControl(void)
{

   if(warmup_complete_flag) return;     // exit if warmup ended
   if(!(TMR0_warmup_flag)) return;
//    The TMR0_warmup_flag is set every 10mS by the TimeBaseManager().
//    The TMR0_warmup_timer is decremented here every 10mS until,
//    after TIMEBASE_WARMUP_ms, it reaches the value of zero. When the timer reaches
//    zero the drivers are initialized and interrupts are enabled. Additional
//    processing is permantly locked out by the warmup_complete_flag.

   TMR0_warmup_flag = 0;

   if(TMR0_warmup_timer) 
   {
      TMR0_warmup_timer--;
   }
   else
   {

      // the SpeedManager() determines when the run_flag goes true
      // wait until commanded by the speed control before completing warmup
      // and progressing to the next stages of initializing and startup
      if(run_flag)
      {
         warmup_complete_flag = 1;         
         InitDriver();         
      }
   }
}


unsigned char FindTableIndex(unsigned int duty_cycle)
{
   // find the closest table index for the supplied value in the table
   // not very efficient but it's only performed during initialization
   unsigned char index;
   
   for(index = 0; CCP_Values[index]<duty_cycle; index++);
   return index;
}

// This function accepts an 8-bit value as an index for a lookup table.
// The table sets a 10-bit value into the CCPR registers
void GetCCPVal(unsigned char speed)
{     
     CCPR1L = (CCP_Values[speed] >> 2);
     DC1B0  = CCP_Values[speed] & 0x01;
     DC1B1  = (CCP_Values[speed] >> 1) & 0x01;
}
