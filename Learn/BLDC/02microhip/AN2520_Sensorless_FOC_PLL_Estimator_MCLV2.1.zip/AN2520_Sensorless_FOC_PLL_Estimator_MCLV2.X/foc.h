/* ************************************************************************** */
/** Descriptive File Name

  @Company
    Company Name

  @File Name
    filename.h

  @Summary
    Brief description of the file.

  @Description
    Describe the purpose of this file.
 */
/* ************************************************************************** */

#ifndef _FOC_H    /* Guard against multiple inclusion */
#define _FOC_H
/* MC Core Variables */


union  SYSTEM_STATUS_UNION 
{
    struct
    {
        unsigned RunMotor:1;  					/* run motor indication */
        unsigned OpenLoop:1;  					/* open loop/clsd loop indication */
        unsigned Btn1Pressed:1; 				/* btn 1 pressed indication */
        unsigned Btn2Pressed:1; 				/* btn 2 pressed indication */
        unsigned ChangeMode:1; 					/* mode changed indication - from open to clsd loop */
        unsigned ChangeSpeed:1; 				/* speed doubled indication */
        unsigned Btn2Debounce:1;
        unsigned ClassBPass:1;
        unsigned    :8;
    }bit;
    
	unsigned short Word;
}mcApp_Control ;        						// general flags


void MC_APP_MC_CalculateParkAngle(void);
void MC_APP_MC_DoControl( void );
void mcApp_InitControlParameters(void);
void mcApp_InitEstimParm(void);
void mcApp_ADCISRTasks(void);


#endif /* _EXAMPLE_FILE_NAME_H */

/* *****************************************************************************
 End of File
 */
