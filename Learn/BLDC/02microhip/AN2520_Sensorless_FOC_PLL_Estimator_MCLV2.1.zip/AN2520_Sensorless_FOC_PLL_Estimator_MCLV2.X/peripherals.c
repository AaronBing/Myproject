#include "peripherals.h"
#include "userparams.h"
#include <xc.h>
void initLEDPorts(void)
{
// Set RF5 as output port to control LED D1 on dsPICDEM MCLV-2/MCVH-3     
    ANSELFbits.ANSF5 = 0; // RF5 as digital port
    TRISFbits.TRISF5 = 0; // RF5 as output port
    LATFbits.LATF5 = 0;   // Set RF5 output = 0

// Set RG15 as output port to control LED D2 on dsPICDEM MCLV-2/MCVH-3        
    ANSELGbits.ANSG15 = 0; // RG15 as digital port
    TRISGbits.TRISG15 = 0; // RG15 as output port
    LATGbits.LATG15 = 0;   // Set RG15 output = 0
}


void initInternalOpamps(void)
{
// Configure DAC2 for AVDD/2 bias for internal op-amps  
    DAC2CONbits.REFSEL = 0b11;            // Reference voltage for DAC2 = AVDD
    DAC2CONbits.DACDAT = VREF_DAC_VALUE;  // Set DAC2 Output to AVDD/2
    DAC2CONbits.DACOE = 1;                // Enable DAC2 output    
    DAC2CONbits.ON = 1;                   // Turn ON DAC2
 
// Configure Internal Opamp
   CFGCON2bits.ENPGA1 = 0; // OPAMP1 in standard 3 terminal mode
   CFGCON2bits.ENPGA2 = 0; // OPAMP2 in standard 3 terminal mode
   CFGCON2bits.ENPGA3 = 0; // OPAMP3 in standard 3 terminal mode
   CM1CONbits.AMPMOD = 1;// OPAMP/CMP1 in OPAMP mode
   CM2CONbits.AMPMOD = 1;// OPAMP/CMP2 in OPAMP mode
   CM3CONbits.AMPMOD = 1;// OPAMP/CMP3 in OPAMP mode
}  

void initFaultComparator(void)
{
// Configure DAC3 as reference threshold for current limit fault comparator (Comparator 3)
   DAC3CONbits.REFSEL = 0b11;  // Reference voltage for DAC3 = AVDD
   DAC3CONbits.DACDAT = CURRENT_LIMIT_CMP_REF-1;// Set DAC3 output to current limit reference
   DAC3CONbits.DACOE = 1; // Enable DAC3 output    
   DAC3CONbits.ON = 1; // Turn ON DAC3

// Configure Comparator 3 as Current Limit Fault Comparator.   
   RPG0Rbits.RPG0R = 7; // Re-map Comparator 3 output to RPG0 PPS pin.
   CM3CONbits.CCH = 0b11; // OPAMP3 output is connected to the inverting input of Comparator 3
   CM3CONbits.CREF = 0b1;// DAC3 Output is connected to the non-inverting input of Comparator 3 
   CM3CONbits.COE = 1;  // Enable Comparator 3 output
   CM3CONbits.ON = 1;  // Turn ON Comparator 3
}  

void initUARTPorts(void)
{
//Set RPB9 as UART2 TX and RPC8 as UART2 RX
ANSELBbits.ANSB9=0; // RPB9 as digital I/O
TRISBbits.TRISB9=0;// RPB9 as output
RPB9Rbits.RPB9R=2; // RPB9 as U2TX
TRISCbits.TRISC8=1; // RPC8 as input
U2RXR = 0b0110; // RPC8 as U2RX   
U2BRG = 96;
U2STAbits.UTXEN =1;
U2STAbits.URXEN =1;
U2MODEbits.ON = 1;
      

}

void initADC(void)
{
//Initialize ADC Calibration Values
    ADC0CFG = DEVADC0;
    ADC1CFG = DEVADC1;
    ADC2CFG = DEVADC2;
    ADC3CFG = DEVADC3;
    ADC4CFG = DEVADC4;
    ADC5CFG = DEVADC5;
    ADC7CFG = DEVADC7;

    ADCCON1 = 0; // No ADCCON1 features are enabled including: Stop-in-Idle, turbo,

    ADCCON2 = 0; // Since, we are using only the Class 1 inputs, no setting is
            // required for ADCDIV
    /* Initialize warm up time register */
    ADCANCON = 0;
    ADCANCONbits.WKUPCLKCNT = 5; // Wakeup exponent = 32 * TADx
    
    /* Clock setting */
    ADCCON3 = 0;
    ADCCON3bits.ADCSEL = 0; // Select input clock source
    ADCCON3bits.CONCLKDIV = 2; // Control clock frequency is same as input clock
    ADCCON3bits.VREFSEL = 0; // Select AVdd and AVss as reference source
    
    /* Select ADC sample time and conversion clock */
    ADC0TIMEbits.ADCDIV = 2; // ADC0 clock frequency is same as control clock = TAD0
    ADC0TIMEbits.SAMC = 0; // ADC0 sampling time = 2 * TAD0
    ADC0TIMEbits.SELRES = 3; // ADC0 resolution is 12 bits
    
    ADC4TIMEbits.ADCDIV = 2; // ADC4 clock frequency is same as control clock = TAD0
    ADC4TIMEbits.SAMC = 0; // ADC4 sampling time = 2 * TAD0
    ADC4TIMEbits.SELRES = 3; // ADC4 resolution is 12 bits    
    
    ADCCON2bits.ADCDIV = 2; // ADC7 clock frequency
    ADCCON2bits.SAMC = 0; // ADC7 sampling time = 2 * TAD0
    ADCCON1bits.SELRES = 3; // ADC7 resolution is 12 bits     
  
    /* Select analog input for ADC modules, no presync trigger, not sync sampling */
    #ifdef INTERNAL_OPAMP
    ADCTRGMODEbits.SH0ALT = 0b01; // ADC0 = AN3  PIM_IMOTOR1 -> IA
    ADCTRGMODEbits.SH4ALT = 0b11; // ADC4 = AN0  PIM_IMOTOR2 -> IB
    #else
    ADCTRGMODEbits.SH0ALT = 0b11; // ADC0 = AN24  PIM_IMOTOR1 -> IA
    ADCTRGMODEbits.SH4ALT = 0b10; // ADC4 = AN9  PIM_IMOTOR2 -> IB
    #endif    
               
    /* Select ADC input mode */
    ADCIMCON2bits.SIGN24 = 0; // unsigned data format AN24  PIM_IMOTOR1 -> IA
    ADCIMCON2bits.DIFF24 = 0; // Single ended mode AN24  PIM_IMOTOR1 -> IA
    ADCIMCON1bits.SIGN9 = 0; // unsigned data format  AN9  PIM_IMOTOR2 -> IB
    ADCIMCON1bits.DIFF9 = 0; // Single ended mode     AN9  PIM_IMOTOR2 -> IB
    ADCIMCON1bits.SIGN10 = 0; // unsigned data format AN10 PIM_VBUS
    ADCIMCON1bits.DIFF10 = 0; // Single ended mode    AN10 PIM_VBUS   
    ADCIMCON1bits.SIGN15 = 0; // unsigned data format AN15 PIM_POT
    ADCIMCON1bits.DIFF15 = 0; // Single ended mode    AN15 PIM_POT   
    

    /* Configure ADCGIRQENx */
    ADCGIRQEN1bits.AGIEN0 = 1; // Enable data ready interrupt for AN0
    ADCGIRQEN2 = 0;
    
    /* Configure ADCCSSx */
    ADCCSS1 = 0; // No scanning is used
    ADCCSS2 = 0;
    /* Configure ADCCMPCONx */
    ADCCMPCON1 = 0; // No digital comparators are used. Setting the ADCCMPCONx
    ADCCMPCON2 = 0; // register to '0' ensures that the comparator is disabled.
    ADCCMPCON3 = 0; // Other registers are ?don't care?.
    ADCCMPCON4 = 0;

    /* Configure ADCFLTRx */
    ADCFLTR1 = 0; // No oversampling filters are used.
    ADCFLTR2 = 0;
    ADCFLTR3 = 0;
    ADCFLTR4 = 0;


     ADCTRGSNSbits.LVL0 = 0; // Edge trigger
    ADCTRG1bits.TRGSRC0 = 10; // Set AN0 to trigger from PWM1
    ADCTRGSNSbits.LVL4 = 0; // Edge trigger                     
    ADCTRG2bits.TRGSRC4 = 10; // Set AN9 to trigger from PWM1   AN9->PIM_IMOTOR2
    ADCTRGSNSbits.LVL10 = 0; // Edge trigger
    ADCTRG3bits.TRGSRC10 = 10; // Set AN10 to trigger from PWM1   AN10 ->PIM_VBUS 
    ADCTRGSNSbits.LVL15 = 0; // Edge trigger
    ADCTRG4bits.TRGSRC15 = 10; // Set AN6 to trigger from PWM1    AN15 -> PIM_POT
    
   // ******Continue from this point.
    
    /* Early interrupt */
    ADCEIEN1 = 0; // No early interrupt
    ADCEIEN2 = 0;
   

    IFS3bits.AD1D0IF = 0;
    IEC3bits.AD1D0IE = 1;
    IPC26bits.AD1D0IP = 3;
    IPC26bits.AD1D0IS = 1;

    INTCONbits.MVEC = 1;
    __builtin_mtc0(12,0,(__builtin_mfc0(12,0) | 0x0001)); // Global Interrupt Enable
    
    /* Turn the ADC on */
    ADCCON1bits.ON = 1;
    /* Wait for voltage reference to be stable */
    while(!ADCCON2bits.BGVRRDY); // Wait until the reference voltage is ready
    while(ADCCON2bits.REFFLT); // Wait if there is a fault with the reference voltage
    /* Enable clock to analog circuit */
    ADCANCONbits.ANEN0 = 1; // Enable the clock to analog bias
    ADCANCONbits.ANEN4 = 1; // Enable the clock to analog bias
    ADCANCONbits.ANEN7 = 1; // Enable the clock to analog bias
  
    /* Wait for ADC to be ready */
    while(!ADCANCONbits.WKRDY0); // Wait until ADC0 is ready
    while(!ADCANCONbits.WKRDY4); // Wait until ADC4 is ready
    while(!ADCANCONbits.WKRDY7); // Wait until ADC7 is ready
   
}

void enableADC(void)
{
    /* Enable the ADC module */
    ADCCON3bits.DIGEN0 = 1; // Enable ADC0    
    ADCCON3bits.DIGEN4 = 1; // Enable ADC4   
    ADCCON3bits.DIGEN7 = 1; // Enable ADC7 
}

void initPWM(void)
{
     PTCON = 0x0000;   

    PDC1 = (PWM_PERIOD_COUNT * 0.0);
    PDC2 = (PWM_PERIOD_COUNT * 0.0);
    PDC3 = (PWM_PERIOD_COUNT * 0.0);

    /* Set PWM Period */
    PTPER = PWM_PERIOD_COUNT;

    /* DTRx Registers are ignored in this mode */
    DTR1 = DTR2 = DTR3 = 75;
    ALTDTR1 = ALTDTR2 = ALTDTR3 = 75;
     
 
#ifdef INTERNAL_OPAMP
    IOCON1 = IOCON2 = IOCON3 = 0x0054C000; //CMP3 as fault input, cycle by cycle fault mode
#else 
    IOCON1 = IOCON2 = IOCON3 = 0x007DC000; //FLT15 as fault input, cycle by cycle fault mode
#endif
    /* Set Independent Time Bases, Center-Aligned mode and Master Duty Cycles */
    
    
        
    PWMCON1 = PWMCON2 = PWMCON3 = 0x00000400; // Set PWM1,PWM2,PWM3 in Symmetric Center Aligned Mode
    LEBCON1 = LEBCON2 = LEBCON3 = 0x0000A800; // Enable Leading Edge Blanking of PWM fault input at rising edges of PWMxH and PWMxL
    LEBDLY1 = LEBDLY2 = LEBDLY3 = 240;        
    IEC5bits.PWM1IE = 1; // Enable PWM Interrupt 
    IPC43bits.PWM1IP = 4; // PWM Interrupt Priority
    PWMCON1bits.FLTIEN = 1; // Enable PWM1 Fault Interrupt
    // Trigger ADC using PWM1, when PWML1 is center of ON
    // trigger slightly before the PTPER, otherwise, interrupt does not occur
    TRIG1 = (PWM_PERIOD_COUNT - 1);
    TRGCON1bits.TRGDIV = 0;
    TRGCON1bits.TRGSEL = 2; // generate trigger in incrementing phase (right hand side)
    TRGCON1bits.STRGSEL = 0;
    TRGCON1bits.DTM = 0;
}

void enablePWM(void)
{
    /* Enable PWM Module */
    PTCON = 0x8000;        
}

void disablePWM(void)
{
    /* Enable PWM Module */
    PTCON = 0x0000;        
}