#ifndef USERPARAMS_H
#define USERPARAMS_H



#define     PBCLK_PWM                                           (120000000ul)
//===============================================================
#define     PWM_FREQ                                            20000
#define     PWM_PERIOD_COUNT                                   (((PBCLK_PWM/PWM_FREQ)/2))
#define     DEADTIME_SEC                                        (float)0.000001
#define     DEADTIME_REG                                        DEADTIME_SEC*PBCLK_PWM
#define     PWM_IOCON_CONFIG                                    0x007DC000    
//===============================================================
// Following parameters for MCLV-2 board
// Gain of opamp = 15
// shunt resistor = 0.025 ohms
// DC offset = 1.65V
// max current = x
// (x * 0.025 * 15) + 1.65V = 3.3V
// x = 4.4Amps
#define     MAX_BOARD_CURRENT                                   (float)(4.4)
#define     MAX_MOTOR_CURRENT                                   (float)(4.4)
#define     MAX_MOTOR_CURRENT_SQUARED                           (float)((float)MAX_MOTOR_CURRENT*(float)MAX_MOTOR_CURRENT)
#define     VREF_DAC_VALUE                                      (int) 2048
#define     ADC_CURRENT_SCALE                                   (float)(MAX_BOARD_CURRENT/(float)2048)

#define     CURRENT_LIMIT_CMP_REF                               (int)(((float)2048*(MAX_MOTOR_CURRENT/MAX_BOARD_CURRENT))+VREF_DAC_VALUE)
#define     MOTOR_PER_PHASE_RESISTANCE                          ((float)2.10)			// Resistance in Ohms
#define     MOTOR_PER_PHASE_INDUCTANCE                          ((float)0.00192)		// Inductance in Henrys
#define     MOTOR_PER_PHASE_INDUCTANCE_DIV_2_PI                 ((float)(MOTOR_PER_PHASE_INDUCTANCE/(2*M_PI)))	
#define     MOTOR_BACK_EMF_CONSTANT_Vpeak_Line_Line_KRPM_MECH   (float)7.24				// Back EMF Constant in Vpeak/KRPM
#define     NOPOLESPAIRS                                        5
#define     MAX_ADC_COUNT                                       (float)4095     // for 12-bit ADC
#define     MAX_ADC_INPUT_VOLTAGE                               (float)3.3      // volts


#define     DCBUS_SENSE_TOP_RESISTOR                            (float)30.0
#define     DCBUS_SENSE_BOTTOM_RESISTOR                         (float)2.0
#define     DCBUS_SENSE_RATIO                                   (float)(DCBUS_SENSE_BOTTOM_RESISTOR/(DCBUS_SENSE_BOTTOM_RESISTOR + DCBUS_SENSE_TOP_RESISTOR))
#define     VOLTAGE_ADC_TO_PHY_RATIO                            (float)(MAX_ADC_INPUT_VOLTAGE/(MAX_ADC_COUNT * DCBUS_SENSE_RATIO))
#define     BTN1                                                (PORTGbits.RG1) // BTN_1 -> Start Switch
#define     BTN2                                                (PORTCbits.RC7) // BTN_2   

#define     SINGLE_ELEC_ROT_RADS_PER_SEC                        (float)(2*M_PI)

#define     MAX_DUTY                                            (PWM_PERIOD_COUNT)
#define     LOOPTIME_SEC                                        (float)0.00005           // PWM Period - 50 uSec, 20Khz PWM

#define     LOCK_TIME_IN_SEC                                     2
#define     LOCK_COUNT_FOR_LOCK_TIME                            (unsigned int)((float)LOCK_TIME_IN_SEC/(float)LOOPTIME_SEC)
#define     END_SPEED_RPM                                       500 // Value in RPM

#define     END_SPEED_RPS                                       ((float)END_SPEED_RPM/60)

// In 1 second, the motor makes "END_SPEED_RPS" mechanical rotations
#define     RAMP_TIME_IN_SEC                                     3
#define     END_SPEED_RADS_PER_SEC_MECH                         (float)(END_SPEED_RPS * SINGLE_ELEC_ROT_RADS_PER_SEC)
#define     END_SPEED_RADS_PER_SEC_ELEC                         (float)(END_SPEED_RADS_PER_SEC_MECH * NOPOLESPAIRS)
#define     END_SPEED_RADS_PER_SEC_ELEC_IN_LOOPTIME             (float)(END_SPEED_RADS_PER_SEC_ELEC * LOOPTIME_SEC)
#define     OPENLOOP_RAMPSPEED_INCREASERATE                     (float)(END_SPEED_RADS_PER_SEC_ELEC_IN_LOOPTIME/(RAMP_TIME_IN_SEC/LOOPTIME_SEC))

#define     CL_RAMP_RATE_RPM_SEC                             500 // CLosed Loop Speed Ramp rate in Rev/min/Sec
#define     CL_RAMP_RATE_RPS_SEC                             ((float)CL_RAMP_RATE_RPM_SEC/60) // CLosed Loop  Speed Ramp rate in Rev/sec^2 
#define     CL_RAMP_RATE_RADS_PER_SEC2_MECH                  (float)(CL_RAMP_RATE_RPS_SEC*2*M_PI) // CLosed Loop  Speed Ramp Rate in Mechanical Radians/Sec^2
#define     CL_RAMP_RATE_RADS_PER_SEC2_ELEC                  (float)(CL_RAMP_RATE_RADS_PER_SEC2_MECH*NOPOLESPAIRS) // CLosed Loop  Speed Ramp rate in Electrical Radians/Sec^2
#define     CL_SPEED_RAMP_RATE_DELTA                         (float)(CL_RAMP_RATE_RADS_PER_SEC2_ELEC*LOOPTIME_SEC) // CLosed Loop  Speed Ramp Rate in Electrical Radians/sec^2 in each control loop time
#define     CL_SPEED_HYSTERESIS                              (float)(5*CL_SPEED_RAMP_RATE_DELTA)

/* end speed converted to fit the startup ramp */
#define     Q_CURRENT_REF_OPENLOOP           0.4

/* Nominal speed of the motor in RPM */
#define     NOMINAL_SPEED_RPM                                   (float)2800 // Value in RPM
#define     NOMINAL_SPEED_RAD_PER_SEC_ELEC                      (float)(((NOMINAL_SPEED_RPM/60)*2*M_PI)*NOPOLESPAIRS) // Value in RPM
   
#define     MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RPM_MECH        (float)((MOTOR_BACK_EMF_CONSTANT_Vpeak_Line_Line_KRPM_MECH/1.732)/1000)
#define     MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RPS_MECH        (float)(MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RPM_MECH * 60)
#define     MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_MECH (float)(MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RPS_MECH/(2*M_PI))
#define     MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_ELEC (float)(MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_MECH/NOPOLESPAIRS)
#define     INVKFi_BELOW_BASE_SPEED                               (float)(1/MOTOR_BACK_EMF_CONSTANT_Vpeak_PHASE_RAD_PER_SEC_ELEC)

/*Moving Average Filter based Current Offset Calculator Parameters */
#define 	MOVING_AVG_WINDOW_SIZE                              18   // moving average window sample size is 2^18
#define     CURRENT_OFFSET_MAX                                  2200 // current offset max limit
#define     CURRENT_OFFSET_MIN                                  1900 // current offset min limit
#define     CURRENT_OFFSET_INIT                                 2048 // // as the OPAMPs are biased at VDD/2, the estimate offset value is 2048 i.e. half of 4095 which is full scale value of a 12 bit ADC. 
/* PI controllers tuning values - */
//******** D Control Loop Coefficients *******
#define     D_CURRCNTR_PTERM                                    0.2
#define     D_CURRCNTR_ITERM                                    (0.0005)
#define     D_CURRCNTR_CTERM                                    0.5
#define     D_CURRCNTR_OUTMAX                                    0.999

//******** Q Control Loop Coefficients *******
#define     Q_CURRCNTR_PTERM                                    0.2
#define     Q_CURRCNTR_ITERM                                   (0.0005)
#define     Q_CURRCNTR_CTERM                                    0.5
#define     Q_CURRCNTR_OUTMAX                                   0.999

//*** Velocity Control Loop Coefficients *****
#define     SPEEDCNTR_PTERM                                      (0.005)
#define     SPEEDCNTR_ITERM                                      (0.00000020) 
#define     SPEEDCNTR_CTERM                                      0.5
#define     SPEEDCNTR_OUTMAX                                     MAX_MOTOR_CURRENT



#define     KFILTER_ESDQ                                        (float)((float)400/(float)32767)
#define     KFILTER_VELESTIM                                    (float)((float)(1*374)/(float)32767)
#define     INITOFFSET_TRANS_OPEN_CLSD                          (float)((float)0x2000/(float)32767)

#define     FW_SPEED_RPM                                        (float)5000
#define     FW_SPEED_RAD_PER_SEC_ELEC                           (float)(((FW_SPEED_RPM/60)*2*M_PI)*NOPOLESPAIRS)
#define     SPEED_COMMAND_RAMP_UP_TIME                          (float)25.0 // seconds
#define     MAX_FW_NEGATIVE_ID_REF                              (float)(-1.6)

#define     POT_ADC_COUNT_FW_SPEED_RATIO                        (float)(FW_SPEED_RAD_PER_SEC_ELEC/MAX_ADC_COUNT)


#define 	DECIMATE_NOMINAL_SPEED  ((NOMINAL_SPEED_RPM *(M_PI/30))*NOPOLESPAIRS/10)


/*Application Configuration Switches*/

/*Define macro INTERNAL_OPAMP to use internal (on-chip) op-amps 
 Undefine macro INTERNAL_OPAMP to use external (on-board) op-amps*/
#define INTERNAL_OPAMP 

/*Define macro OPEN_LOOP_FUNCTIONING to run the speed control in open loop.
 In this mode, the rotor angle is assumed and is not in sync with the actual rotor
 angle. This mode can be used to debug current loops and rotor position
 estimator*/

/*Undefine macro OPEN_LOOP_FUNCTIONING to run the speed control in closed loop.
 In this mode, the rotor angle is estimated using PLL based estimator. */
#undef OPEN_LOOP_FUNCTIONING 

/*Define macro TORQUE_MODE to run the motor in TORQUE Control Mode
 Undefine macro TORQUE_MODE to run the motor in Speed Control Mode*/
#undef TORQUE_MODE

#endif
