#include <xc.h>
#include "userparams.h"
#include "peripherals.h"
#include "foc.h"
#include "mc_Lib.h"
#include <sys/attribs.h>
//#define _CP0_GET_COUNT() __builtin_mfc0(9,0);
// <editor-fold defaultstate="collapsed" desc="Configuration Bits">

/*** DEVCFG0 ***/

#pragma config DEBUG =      OFF
#pragma config JTAGEN =     OFF
#pragma config ICESEL =     ICS_PGx2
#pragma config TRCEN =      OFF
#pragma config BOOTISA =    MIPS32
#pragma config FSLEEP =     OFF
#pragma config DBGPER =     PG_ALL
#pragma config SMCLR =      MCLR_NORM
#pragma config SOSCGAIN =   GAIN_2X
#pragma config SOSCBOOST =  ON
#pragma config POSCGAIN =   GAIN_LEVEL_3
#pragma config POSCBOOST =  ON
#pragma config EJTAGBEN =   NORMAL
#pragma config CP =         OFF

/*** DEVCFG1 ***/

#pragma config FNOSC =      SPLL
#pragma config DMTINTV =    WIN_127_128
#pragma config FSOSCEN =    ON
#pragma config IESO =       ON
#pragma config POSCMOD =    EC
#pragma config OSCIOFNC =   OFF
#pragma config FCKSM =      CSECME
#pragma config WDTPS =      PS1048576
#pragma config WDTSPGM =    STOP
#pragma config FWDTEN =     OFF
#pragma config WINDIS =     NORMAL
#pragma config FWDTWINSZ =  WINSZ_25
#pragma config DMTCNT =     DMT31
#pragma config FDMTEN =     OFF
/*** DEVCFG2 ***/

#pragma config FPLLIDIV =   DIV_3
#pragma config FPLLRNG =    RANGE_5_10_MHZ
#pragma config FPLLICLK =   PLL_POSC
#pragma config FPLLMULT =   MUL_60
#pragma config FPLLODIV =   DIV_4
#pragma config VBATBOREN =  ON
#pragma config DSBOREN =    ON
#pragma config DSWDTPS =    DSPS32
#pragma config DSWDTOSC =   LPRC
#pragma config DSWDTEN =    OFF
#pragma config FDSEN =      ON
#pragma config BORSEL =     HIGH
#pragma config UPLLEN =     OFF
/*** DEVCFG3 ***/

#pragma config USERID =     0xffff
#pragma config FUSBIDIO2 =   ON
#pragma config FVBUSIO2 =  ON
#pragma config PGL1WAY =    ON
#pragma config PMDL1WAY =   ON
#pragma config IOL1WAY =    ON
#pragma config FUSBIDIO1 =   ON
#pragma config FVBUSIO1 =  ON
#pragma config PWMLOCK =  OFF

/*** BF1SEQ0 ***/

#pragma config TSEQ =       0x0000
#pragma config CSEQ =       0xffff
// </editor-fold>


extern mcParam_SinCos					    mcApp_SincosParam;
extern mcParam_SVPWM                       mcApp_SVGenParam;

int main(void)
{
   
 
      // <editor-fold defaultstate="collapsed" desc="Make kseg0 Cacheable">
    register unsigned long tmp_cache;
    asm("mfc0 %0,$16,0" :  "=r"(tmp_cache));
    tmp_cache = (tmp_cache & ~7) | 3;
    asm("mtc0 %0,$16,0" :: "r" (tmp_cache));
    // </editor-fold>
        CHECONbits.PFMWS=3; // Flash wait states = 3 CPU clock cycles
        CHECONbits.PREFEN = 1; // Enable Prefetch Cache
    initLEDPorts(); // Initialize I/O Ports that drive LED D1 and D2
    initUARTPorts(); // Initialize I/O Ports that drive UART TX and RX 
    initADC(); // Initialize ADC
    initPWM();// Initialize PWM
    enableADC();// enable ADC
#ifdef INTERNAL_OPAMP
    initInternalOpamps();
    initFaultComparator();
#endif 
    //////////////////////////////////////
    // X2CScope_Init();
    //////////////////////////////////////
    X2CScope_Init();
   while(BTN1)
   {
       //////////////////////////////////////
        // X2CScope_Communicate();
        //////////////////////////////////////
        X2CScope_Communicate();
         X2CScope_Update();
   }
     
    mcApp_Control.bit.Btn1Pressed = 1;
    mcApp_Control.bit.OpenLoop = 1;
    mcApp_Control.bit.ChangeMode = 1;
    mcApp_InitControlParameters();
	mcApp_InitEstimParm();
    mcApp_SincosParam.Angle = 0;
	mcApp_SVGenParam.PWMPeriod = (float)MAX_DUTY;
   
    enablePWM();
    
	while(1)
    {
      
        //////////////////////////////////////
        // X2CScope_Communicate();
        //////////////////////////////////////
        X2CScope_Communicate();
        
    }
     
}

void __ISR(_ADC_DATA0_VECTOR, ipl3auto)ADCISR(void)
{
   
    mcApp_ADCISRTasks();
    X2CScope_Update();
    IFS3bits.AD1D0IF = 0; 
    
}

void __ISR(_PWM1_VECTOR, ipl4auto)MCPWM_FAULT_ISR(void)
{       
       disablePWM();
       LATGSET=0x8000;  // Set LED D2 to indicate Fault
       PWMCON1bits.TRGIF = 0;
       IFS5bits.PWM1IF = 0;
}