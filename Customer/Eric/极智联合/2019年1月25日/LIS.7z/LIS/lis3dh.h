
#ifndef __LIS3DH_H
#define __LIS3DH_H

#include "stm32f0xx.h"


//#define SET_BIT(REG, BIT)     ((REG) |= (BIT))
//#define CLEAR_BIT(REG, BIT)   ((REG) &= ~(BIT))
#define ValBit(VAR,Place)		(VAR & (1<<Place))
#define BIT(x) ( (x) )

/* Maximum Timeout values for flags and events waiting loops. These timeouts are
   not based on accurate values, they just guarantee that the application will 
   not remain stuck if the I2C communication is corrupted.
   You may modify these timeout values depending on CPU frequency and application
   conditions (interrupts routines ...). */ 
#define sEE_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define sEE_LONG_TIMEOUT         ((uint32_t)(10 * sEE_FLAG_TIMEOUT))

#define LIS3DH_ADDR  0x30

#define LIS3DH_WHO_AM_I		0x0F  // device identification register
// CONTROL REGISTER 1
#define LIS3DH_CTRL_REG1				0x20
#define LIS3DH_ODR_BIT			BIT(4)
#define LIS3DH_LPEN					BIT(3)
#define LIS3DH_ZEN					BIT(2)
#define LIS3DH_YEN					BIT(1)
#define LIS3DH_XEN					BIT(0)

//CONTROL REGISTER 2
#define LIS3DH_CTRL_REG2				0x21
#define LIS3DH_HPM     				BIT(6)
#define LIS3DH_HPCF						BIT(4)
#define LIS3DH_FDS						BIT(3)
#define LIS3DH_HPCLICK				BIT(2)
#define LIS3DH_HPIS2					BIT(1)
#define LIS3DH_HPIS1					BIT(0)

//CONTROL REGISTER 3
#define LIS3DH_CTRL_REG3				0x22
#define LIS3DH_I1_CLICK				BIT(7)
#define LIS3DH_I1_AOI1				BIT(6)
#define LIS3DH_I1_AOI2				BIT(5)
#define LIS3DH_I1_DRDY1				BIT(4)
#define LIS3DH_I1_DRDY2				BIT(3)
#define LIS3DH_I1_WTM				BIT(2)
#define LIS3DH_I1_ORUN				BIT(1)

//CONTROL REGISTER 4
#define LIS3DH_CTRL_REG4				0x23
#define LIS3DH_BDU					BIT(7)
#define LIS3DH_BLE					BIT(6)
#define LIS3DH_FS					BIT(4)
#define LIS3DH_HR					BIT(3)
#define LIS3DH_ST       			BIT(1)
#define LIS3DH_SIM					BIT(0)

//CONTROL REGISTER 5
#define LIS3DH_CTRL_REG5				0x24
#define LIS3DH_BOOT             BIT(7)
#define LIS3DH_FIFO_EN          BIT(6)
#define LIS3DH_LIR_INT1         BIT(3)
#define LIS3DH_D4D_INT1         BIT(2)

//CONTROL REGISTER 6
#define LIS3DH_CTRL_REG6				0x25
#define LIS3DH_I2_CLICK				BIT(7)
#define LIS3DH_I2_INT1				BIT(6)
#define LIS3DH_I2_BOOT        		BIT(4)
#define LIS3DH_H_LACTIVE			BIT(1)

//TEMPERATURE CONFIG REGISTER
#define LIS3DH_TEMP_CFG_REG				0x1F
#define LIS3DH_ADC_PD				    BIT(7)
#define LIS3DH_TEMP_EN					BIT(6)

//REFERENCE/DATA_CAPTURE
#define LIS3DH_REFERENCE_REG		  0x26
#define LIS3DH_REF		          BIT(0)

//STATUS_REG_AXIES
#define LIS3DH_STATUS_REG				0x27
#define LIS3DH_ZYXOR            BIT(7)
#define LIS3DH_ZOR              BIT(6)
#define LIS3DH_YOR              BIT(5)
#define LIS3DH_XOR              BIT(4)
#define LIS3DH_ZYXDA            BIT(3)
#define LIS3DH_ZDA              BIT(2)
#define LIS3DH_YDA              BIT(1)
#define LIS3DH_XDA              BIT(0)

//STATUS_REG_AUX
#define LIS3DH_STATUS_AUX				0x07

//INTERRUPT 1 CONFIGURATION
#define LIS3DH_INT1_CFG				0x30
#define LIS3DH_ANDOR          BIT(7)
#define LIS3DH_INT_6D         BIT(6)
#define LIS3DH_ZHIE           BIT(5)
#define LIS3DH_ZLIE           BIT(4)
#define LIS3DH_YHIE           BIT(3)
#define LIS3DH_YLIE           BIT(2)
#define LIS3DH_XHIE           BIT(1)
#define LIS3DH_XLIE           BIT(0)

//#define LIS3DH_INT1_SRC     0X31  //read-only reg

//#define LIS3DH_INT1_THS     0X32

//#define LIS3DH_INT1_DUR     0X33

//FIFO CONTROL REGISTER
#define LIS3DH_FIFO_CTRL_REG      0x2E
#define LIS3DH_FM               BIT(6)
#define LIS3DH_TR               BIT(5)
#define LIS3DH_FTH              BIT(0)

void LIS3DH_Init(void);
//int8_t LIS3DH_ReadData(void);
int8_t LIS3DH_X_ReadData(void);
int8_t LIS3DH_Y_ReadData(void);
int8_t LIS3DH_Z_ReadData(void);
			
uint8_t LIS3DH_ReadID(void);


#endif 
