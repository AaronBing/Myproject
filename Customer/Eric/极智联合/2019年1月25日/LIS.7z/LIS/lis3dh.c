
#include "lis3dh.h"
#include "uart.h"
#include "iic.h"

//int16_t		accData[];
int8_t		Out_X_L,Out_X_H,Out_Y_L,Out_Y_H,Out_Z_L,Out_Z_H;
int8_t		accData[6];
int16_t X_Data,Y_Data,Z_Data;


void LIS3DH_Init(void)
{
	uint8_t value = 0x57;  // 100Hz  start sensor, X,Y,Zʹ��
	
	I2C1_Write_NBytes(LIS3DH_ADDR,LIS3DH_CTRL_REG1, 1, &value);

	value = 0x08;  // 16g  �߷ֱ��� ����ģʽ
	I2C1_Write_NBytes(LIS3DH_ADDR,LIS3DH_CTRL_REG4, 1, &value);
	
	value = 0x00;  // INT1  INT2 ��ƽ����Ϊ��
	I2C1_Write_NBytes(LIS3DH_ADDR,LIS3DH_CTRL_REG6, 1, &value);	
	
}

int8_t LIS3DH_X_ReadData(void)
{
	int8_t acc_x;
	
	I2C1_Read_NBytes(LIS3DH_ADDR,0x29,1, &Out_X_H);	
	acc_x = Out_X_H;
	
	return acc_x;
}
int8_t LIS3DH_Y_ReadData(void)
{
	int8_t acc_y;
	
	I2C1_Read_NBytes(LIS3DH_ADDR,0x2B,1, &Out_Y_H);	
	acc_y = Out_Y_H;
	
	return acc_y;
}

int8_t LIS3DH_Z_ReadData(void)
{
	int8_t acc_z;
	
	I2C1_Read_NBytes(LIS3DH_ADDR,0x2D,1, &Out_Z_H);	
	acc_z = Out_Z_H;
	
	return acc_z;
}


/**
  * @brief   ��ȡ3DH��ID
  * @param   
  * @retval 
  */

uint8_t LIS3DH_ReadID(void)
{
	int8_t Re;
   I2C1_Read_NBytes(LIS3DH_ADDR,LIS3DH_WHO_AM_I,1,&Re);    //��������ַ
	if(Re != 0x33)
	{
		printf(" LIS3DH dectected error!\r\n ");
		return 0;
	}
	else
	{
		printf(" LIS3DH ID = %d\r\n",Re);
		return 1;
	}		
}

